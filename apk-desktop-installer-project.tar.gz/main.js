// main.js
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');
const extract = require('extract-zip');
const { exec } = require('child_process');
const AppInfoParser = require('app-info-parser');

// Dynamically import node-fetch for ESM compatibility
let fetchFn;
async function getFetch() {
  if (!fetchFn) {
    const mod = await import('node-fetch');
    fetchFn = mod.default;
  }
  return fetchFn;
}

// Download and extract platform-tools if missing
async function setupTools() {
  const toolsDir = path.join(app.getPath('userData'), 'platform-tools');
  const adbBinary = os.platform() === 'win32' ? 'adb.exe' : 'adb';

  if (fs.existsSync(path.join(toolsDir, adbBinary))) {
    return toolsDir;
  }

  const zipPath = path.join(app.getPath('userData'), 'platform-tools.zip');
  const urls = {
    win32: 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip',
    darwin: 'https://dl.google.com/android/repository/platform-tools-latest-darwin.zip',
    linux: 'https://dl.google.com/android/repository/platform-tools-latest-linux.zip'
  };
  const downloadUrl = urls[os.platform()];

  const fetch = await getFetch();
  const response = await fetch(downloadUrl);
  if (!response.ok) {
    throw new Error('Failed to download platform-tools: ' + response.statusText);
  }

  await new Promise((resolve, reject) => {
    const fileStream = fs.createWriteStream(zipPath);
    response.body
      .pipe(fileStream)
      .on('finish', resolve)
      .on('error', reject);
  });

  await extract(zipPath, { dir: app.getPath('userData') });
  fs.unlinkSync(zipPath);
  return toolsDir;
}

// Execute ADB commands and return combined output
function execAdb(command) {
  return new Promise((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        return reject(new Error(stderr || error.message));
      }
      resolve((stdout + stderr).trim());
    });
  });
}

// IPC: List connected ADB devices
ipcMain.handle('list-local', async () => {
  const toolsDir = await setupTools();
  const adbPath = path.join(toolsDir, os.platform() === 'win32' ? 'adb.exe' : 'adb');
  const output = await execAdb(`"${adbPath}" devices -l`);

  return output
    .split(/\r?\n/)
    .slice(1)
    .filter(line => line.trim())
    .map(line => {
      const [id, , ...rest] = line.split(/\s+/);
      return { id, info: rest.join(' ') };
    });
});

// IPC: Connect to a device over TCP
ipcMain.handle('connect-tcp', async (_event, hostPort) => {
  const toolsDir = await setupTools();
  const adbPath = path.join(toolsDir, os.platform() === 'win32' ? 'adb.exe' : 'adb');
  return await execAdb(`"${adbPath}" connect ${hostPort}`);
});

// IPC: Show file picker to select APK
ipcMain.handle('select-apk', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    filters: [{ name: 'APK Files', extensions: ['apk'] }],
    properties: ['openFile']
  });
  return canceled ? null : filePaths[0];
});

// IPC: Parse APK to retrieve its package name
ipcMain.handle('get-package', async (_event, apkPath) => {
  const parser = new AppInfoParser(apkPath);
  const { package: pkgName, packageName } = await parser.parse();
  return pkgName || packageName;
});

// IPC: Install APK on specified device
ipcMain.handle('install-apk', async (_event, deviceId, apkPath) => {
  const toolsDir = await setupTools();
  const adbPath = path.join(toolsDir, os.platform() === 'win32' ? 'adb.exe' : 'adb');
  return await execAdb(`"${adbPath}" -s ${deviceId} install -r "${apkPath}"`);
});

// IPC: Setup app permissions and app-ops on device
ipcMain.handle('setup-permissions', async (_event, deviceId, pkg) => {
  const toolsDir = await setupTools();
  const adbPath = path.join(toolsDir, os.platform() === 'win32' ? 'adb.exe' : 'adb');
  const commands = [
    `shell monkey -p ${pkg} 1`,
    `shell appops set ${pkg} SYSTEM_ALERT_WINDOW allow`,
    `shell pm grant ${pkg} android.permission.WRITE_SECURE_SETTINGS`,
    `shell pm grant ${pkg} android.permission.READ_PHONE_STATE`,
    // `shell pm grant ${pkg} android.permission.READ_LOGS`,
    `shell settings put secure enabled_accessibility_services ${pkg}/com.hoppr.android.services.HopprAppInfoService`,
    `shell am startservice ${pkg}/com.hoppr.android.services.HopprCoreService`,
    `shell pidof ${pkg} >/dev/null && echo "✔ App is running and installed successfully" || echo "✖ App is NOT running"`
  ];
  let fullResult = '';

  for (const cmd of commands) {
    const res = await execAdb(`"${adbPath}" -s ${deviceId} ${cmd}`);
    fullResult += res + '\n';
  }
  return fullResult.trim();
});

// IPC: Display native error dialog
ipcMain.handle('show-error', (_event, message) => {
  dialog.showErrorBox('Error', message);
});

// App ready: create window and initialize
app.whenReady().then(async () => {
  await setupTools();

  const mainWindow = new BrowserWindow({
    width: 950,
    height: 950,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  });
  mainWindow.removeMenu();
  mainWindow.loadFile('index.html');
});