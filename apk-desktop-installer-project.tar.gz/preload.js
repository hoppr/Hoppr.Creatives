const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  listLocal: () => ipcRenderer.invoke('list-local'),
  connectTcp: host => ipcRenderer.invoke('connect-tcp', host),
  selectApk: () => ipcRenderer.invoke('select-apk'),
  getPackage: path => ipcRenderer.invoke('get-package', path),
  installApk: (device, path) => ipcRenderer.invoke('install-apk', device, path),
  setupPerms: (device, pkg) => ipcRenderer.invoke('setup-permissions', device, pkg),
  showError: msg => ipcRenderer.invoke('show-error', msg),
});